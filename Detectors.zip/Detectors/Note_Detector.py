from numpy import array, zeros, uint8
from cv2 import cvtColor, inRange, blur, threshold, findContours, fitEllipse, contourArea, COLOR_BGR2HSV, THRESH_BINARY, RETR_TREE, CHAIN_APPROX_SIMPLE

class Note_Detector:
    def __init__(self, width, height):
        #HSV
        #Have a back up color, but ideally have a func thats
        #Reads from json file, that gets most recent callibration
        self.lower_orange, self.upper_orange = array([0, 150, 38]), array([20, 255, 255])

        self.hsv_frame, self.mask_frame, self.blur_frame  = zeros(shape = (width, height, 3), dtype = uint8), zeros(shape = (width, height, 1), dtype = uint8), zeros(shape = (width, height, 1), dtype = uint8)
        
        self.lower_brightness, self.upper_brightness = 127, 255
        
        self.lower_area, self.upper_area = 1000, 10000

    def get_notes(self, frame):
        # Image Pre Processing
        self.hsv_frame = cvtColor(frame, COLOR_BGR2HSV)
        self.mask_frame = inRange(self.hsv_frame, self.lower_orange, self.upper_orange)
        self.blur_frame = blur(self.mask_frame, (3,3))
        
        # 
        detections = self.get_contours(self.blur_frame)

        return detections

    # favorite algo so far
    # might be able to get distance and angle of note
    # ellipse -> circle
    def get_contours(self, frame):
        ret, thresh = threshold(frame, self.lower_brightness, self.upper_brightness, THRESH_BINARY)
        contours, hierarchy = findContours(thresh, RETR_TREE, CHAIN_APPROX_SIMPLE)

        ellipse_list = [fitEllipse(con) for con in contours if self.lower_area < contourArea(con) < self.upper_area] 
        # contours_area = []
        # ellipse_list = []
        # for con in contours:
        #     area = cv.contourArea(con)
        #     if self.lower_area < area < self.upper_area:
        #         ellipse = cv.fitEllipse(con)
        #         ellipse_list.append(ellipse)
        #         contours_area.append(con)
        return ellipse_list