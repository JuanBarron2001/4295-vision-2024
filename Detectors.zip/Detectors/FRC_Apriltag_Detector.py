from numpy import matrix, arctan2, sqrt, identity, dot, array, zeros,sum
from math import cos, sin
import cv2

class FRC_Apriltag:
    def __init__(self, corners, id, pose_estimation):
        rvec, tvec, markerPoints = pose_estimation
        
        self.id = id
        
        corners = corners[0]
        print('corners', corners)
        sum = corners.sum(axis=0) * .25
        print('sum', sum)
        self.center = (int(sum[0]), int(sum[1]))
        
        self.top_left_point = (int(corners[2][0]), int(corners[2][1]))
        self.top_right_point = (int(corners[3][0]), int(corners[3][1])) #
        self.bottom_left_point = (int(corners[1][0]), int(corners[1][1]))
        self.bottom_right_point = (int(corners[0][0]), int(corners[0][1]))

        print(pose_estimation)

        rot = rvec[0][0]
        trans = tvec[0][0]
        
        self.yaw, self.pitch, self.roll = rot[0], rot[1], rot[2]
        self.x, self.y, self.z = trans[0], trans[1], trans[2]

class FRC_Apriltag_Detector:
    def __init__(self, width, height):
        self.frc_apriltag_location = {
                    1 : matrix('0,0,0,0'),
                    2 : matrix('0,0,0,0'),
                    3 : matrix('0,0,0,0'),
                    4 : matrix('0,0,0,0'),
                    5 : matrix('0,0,0,0'),
                    6 : matrix('0,0,0,0'),
                    7 : matrix('0,0,0,0'),
                    8 : matrix('0,0,0,0'),
                    9 : matrix('0,0,0,0'),
                    10 : matrix('0,0,0,0'),
                    11 : matrix('0,0,0,0'),
                    12 : matrix('0,0,0,0'),
                    13 : matrix('0,0,0,0'),
                    14 : matrix('0,0,0,0'),
                    15 : matrix('0,0,0,0'),
                    16 : matrix('0,0,0,0')
               }
        
        self.arucoDict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_APRILTAG_36h11)
        self.arucoParams = cv2.aruco.DetectorParameters()
        self.detector = cv2.aruco.ArucoDetector(self.arucoDict, self.arucoParams)
        
        self.intrinsic_camera = array(((878.94609, 0, 645.25368),(0,872.55889, 318.12183),(0,0,1)))
        self.distortion = array((-0.42336, 0.25551, .00349, -.00068))

        self.camera_stats = (878.946,872.559,645.254,318.122) #move these to a constants.py
        self.frc_tags_length_size_m = .165 #move these to a constants.py
        
        self.gray_frame = zeros(shape = (width, height, 3))

    def get_frc_apriltags(self, frame):
        self.gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        corners, ids, rejected_img_points = self.detector.detectMarkers(self.gray_frame)
        
        frc_tags = []
        if len(corners) > 0:
            frc_tags = [FRC_Apriltag(corners[i], ids[i], cv2.aruco.estimatePoseSingleMarkers(corners, 152.4,self.intrinsic_camera, self.distortion)) for i in range(len(ids))]
        
        return frc_tags

